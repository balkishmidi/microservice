/*
package com.example.clubservice.services;

public interface IClubMembersService {
    public CLubMembers subscribe(Long clubId, Long memberId);
    public void unsubscribe(Long clubId, Long memberId);


}
*/
