package com.example.clubservice.entites;

public enum TypeChambre {
    SIMPLE,DOUBLE,TRIPLE
}
