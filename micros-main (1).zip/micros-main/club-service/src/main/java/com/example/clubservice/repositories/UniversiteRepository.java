package com.example.clubservice.repositories;

import com.example.clubservice.entites.Universite;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UniversiteRepository extends JpaRepository<Universite, Long> {
}
